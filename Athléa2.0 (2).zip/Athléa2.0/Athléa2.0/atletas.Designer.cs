﻿namespace Athléa2._0
{
    partial class atletas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvAtletas = new DataGridView();
            label1 = new Label();
            txtBuscar = new TextBox();
            btnbuscar = new Button();
            button2 = new Button();
            button1 = new Button();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvAtletas).BeginInit();
            SuspendLayout();
            // 
            // dgvAtletas
            // 
            dgvAtletas.AllowUserToAddRows = false;
            dgvAtletas.AllowUserToDeleteRows = false;
            dgvAtletas.BackgroundColor = Color.FromArgb(186, 221, 127);
            dgvAtletas.BorderStyle = BorderStyle.None;
            dgvAtletas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAtletas.Location = new Point(47, 106);
            dgvAtletas.Margin = new Padding(3, 4, 3, 4);
            dgvAtletas.Name = "dgvAtletas";
            dgvAtletas.ReadOnly = true;
            dgvAtletas.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvAtletas.Size = new Size(409, 340);
            dgvAtletas.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Small", 12F, FontStyle.Bold);
            label1.Location = new Point(165, 56);
            label1.Name = "label1";
            label1.Size = new Size(143, 24);
            label1.TabIndex = 1;
            label1.Text = "Lista de Atletas";
            // 
            // txtBuscar
            // 
            txtBuscar.Location = new Point(474, 106);
            txtBuscar.Margin = new Padding(3, 4, 3, 4);
            txtBuscar.Name = "txtBuscar";
            txtBuscar.Size = new Size(393, 22);
            txtBuscar.TabIndex = 2;
            // 
            // btnbuscar
            // 
            btnbuscar.BackColor = Color.FromArgb(239, 171, 163);
            btnbuscar.Cursor = Cursors.Hand;
            btnbuscar.FlatAppearance.BorderColor = Color.FromArgb(186, 221, 127);
            btnbuscar.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnbuscar.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnbuscar.FlatStyle = FlatStyle.Flat;
            btnbuscar.Font = new Font("Sitka Small", 9F, FontStyle.Bold);
            btnbuscar.Location = new Point(537, 200);
            btnbuscar.Margin = new Padding(3, 4, 3, 4);
            btnbuscar.Name = "btnbuscar";
            btnbuscar.Size = new Size(115, 34);
            btnbuscar.TabIndex = 3;
            btnbuscar.Text = "Buscar atleta";
            btnbuscar.UseVisualStyleBackColor = false;
            btnbuscar.Click += btnbuscar_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(239, 171, 163);
            button2.Cursor = Cursors.Hand;
            button2.FlatAppearance.BorderColor = Color.FromArgb(186, 221, 127);
            button2.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            button2.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Sitka Small", 9F, FontStyle.Bold);
            button2.Location = new Point(615, 264);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(115, 34);
            button2.TabIndex = 4;
            button2.Text = "Eliminar atleta";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(239, 171, 163);
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderColor = Color.FromArgb(186, 221, 127);
            button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Sitka Small", 9F, FontStyle.Bold);
            button1.Location = new Point(681, 200);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(115, 34);
            button1.TabIndex = 6;
            button1.Text = "Agregar atleta";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Small", 12F, FontStyle.Bold);
            label2.Location = new Point(597, 56);
            label2.Name = "label2";
            label2.Size = new Size(133, 24);
            label2.TabIndex = 7;
            label2.Text = "Buscar Atletas";
            // 
            // atletas
            // 
            AutoScaleDimensions = new SizeF(8F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(248, 240, 218);
            BackgroundImage = Properties.Resources.fondo;
            ClientSize = new Size(914, 540);
            Controls.Add(label2);
            Controls.Add(button1);
            Controls.Add(button2);
            Controls.Add(btnbuscar);
            Controls.Add(txtBuscar);
            Controls.Add(label1);
            Controls.Add(dgvAtletas);
            Font = new Font("Sitka Small", 9F, FontStyle.Bold);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "atletas";
            Text = "atletas";
            Load += atletas_Load;
            ((System.ComponentModel.ISupportInitialize)dgvAtletas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvAtletas;
        private Label label1;
        private TextBox txtBuscar;
        private Button btnbuscar;
        private Button button2;
        private Button button1;
        private Label label2;
    }
}