﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace Athléa2._0
{
    public partial class reportesgenerales : Form
    {
        public reportesgenerales()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {

            string connectionString = "Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True;Trust Server Certificate=True";

            string sqlInsert = "INSERT INTO Reporte (titulo, contenido, fecha) VALUES (@titulo, @contenido, @fecha)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sqlInsert, con);
                cmd.Parameters.AddWithValue("@titulo", txtTitulo.Text.Trim());
                cmd.Parameters.AddWithValue("@contenido", rtbContenido.Text.Trim());
                cmd.Parameters.AddWithValue("@fecha", dtpFecha.Value.Date);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            MessageBox.Show("Reporte guardado correctamente.");
        }

        private int idUsuario;

        public reportesgenerales(int idUsuario)
        {
           
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            {
                CargarReportes();

            } 
        }

                private void CargarReportes()
        {
            string connectionString = "Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True;Trust Server Certificate=True";

            string sqlSelect = "SELECT id, titulo, contenido, fecha FROM Reporte";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(sqlSelect, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                dgvReportes.DataSource = dt;
            }
        }
       
    }
        }
    


