﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Athléa2._0
{
    public partial class AgregarAtleta : Form
    {
        public AgregarAtleta()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text;
            string edad = txtEdad.Text;
            string nacionalidad = txtNacionalidad.Text;
            string provincia = txtProvincia.Text;
            string telefono = txtTelefono.Text;
            DateTime fechaNacimiento = dtpFecha.Value;
            string disciplina = txtDisciplina.Text;
            string sexo = "";

            if (rbtnMasculino.Checked)
                sexo = "M";
            else if (rbtnFemenino.Checked)
                sexo = "F";

            // Validación de campos obligatorios
            if (txtNombre.Text == "" || txtEdad.Text == "")
            {
                MessageBox.Show("Por favor completa todos los campos obligatorios.");
                return;
            }



            MessageBox.Show("Atleta registrado correctamente.");
            this.Close(); 


            // Validación básica
            if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(edad))
            {
                MessageBox.Show("Por favor, completa todos los campos obligatorios.");
                return;
            }

            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True"))
            {
                string query = "INSERT INTO Atleta (nombre_completo, edad, nacionalidad, provincia, telefono, fecha_nacimiento, disciplina, sexo) " +
                               "VALUES (@nombre, @edad, @nacionalidad, @provincia, @telefono, @fechaNacimiento, @disciplina, @sexo)";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@nombre", nombre);
                    cmd.Parameters.AddWithValue("@edad", edad);
                    cmd.Parameters.AddWithValue("@nacionalidad", nacionalidad);
                    cmd.Parameters.AddWithValue("@provincia", provincia);
                    cmd.Parameters.AddWithValue("@telefono", telefono);
                    cmd.Parameters.AddWithValue("@fechaNacimiento", fechaNacimiento);
                    cmd.Parameters.AddWithValue("@disciplina", disciplina);
                    cmd.Parameters.AddWithValue("@sexo", sexo);

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Atleta agregado exitosamente.");
                        this.Close(); 
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al guardar: " + ex.Message);
                    }
                }
            }
        }





          

        private void btncancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
