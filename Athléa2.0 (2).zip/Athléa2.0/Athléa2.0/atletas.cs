﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Athléa2._0
{
    public partial class atletas : Form
    {
        public atletas()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dgvAtletas.CurrentRow != null)
            {
                int id = Convert.ToInt32(dgvAtletas.CurrentRow.Cells["id"].Value);

                SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True");
                conexion.Open();
                SqlCommand comando = new SqlCommand("DELETE FROM Atleta WHERE id = @id", conexion);
                comando.Parameters.AddWithValue("@id", id);
                comando.ExecuteNonQuery();
                conexion.Close();

                MessageBox.Show("Atleta eliminado");
                CargarAtletas();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AgregarAtleta formAgregar = new AgregarAtleta();
            formAgregar.ShowDialog();
        }

        private void atletas_Load(object sender, EventArgs e)
        {
           
        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True");
            SqlDataAdapter adaptador = new SqlDataAdapter("SELECT * FROM Atleta WHERE nombre_completo LIKE @nombre_completo", conexion);
            adaptador.SelectCommand.Parameters.AddWithValue("@nombre_completo", "%" + txtBuscar.Text + "%");
            DataTable tabla = new DataTable();
            adaptador.Fill(tabla);
            dgvAtletas.DataSource = tabla;
        }

        void CargarAtletas()
        {
            SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True");
            SqlDataAdapter adaptador = new SqlDataAdapter("SELECT * FROM Atleta", conexion);
            DataTable tabla = new DataTable();
            adaptador.Fill(tabla);
            dgvAtletas.DataSource = tabla;
        }
    }
}
