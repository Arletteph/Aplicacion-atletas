﻿namespace Athléa2._0
{
    partial class Disciplinas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtNombre = new TextBox();
            txtBuscar = new TextBox();
            dgvDisciplinas = new DataGridView();
            btnAgregar = new Button();
            btnEliminar = new Button();
            btbBuscar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvDisciplinas).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(254, 46);
            label1.Name = "label1";
            label1.Size = new Size(263, 31);
            label1.TabIndex = 0;
            label1.Text = "Gestión de Disciplinas";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label2.Location = new Point(56, 125);
            label2.Name = "label2";
            label2.Size = new Size(180, 19);
            label2.TabIndex = 1;
            label2.Text = "Nombre de la disciplina:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label3.Location = new Point(56, 180);
            label3.Name = "label3";
            label3.Size = new Size(134, 19);
            label3.TabIndex = 2;
            label3.Text = "Buscar disciplina:";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(233, 125);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(154, 23);
            txtNombre.TabIndex = 3;
            // 
            // txtBuscar
            // 
            txtBuscar.Location = new Point(233, 177);
            txtBuscar.Name = "txtBuscar";
            txtBuscar.Size = new Size(154, 23);
            txtBuscar.TabIndex = 4;
            // 
            // dgvDisciplinas
            // 
            dgvDisciplinas.BackgroundColor = Color.FromArgb(186, 221, 127);
            dgvDisciplinas.BorderStyle = BorderStyle.None;
            dgvDisciplinas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDisciplinas.Location = new Point(471, 106);
            dgvDisciplinas.Name = "dgvDisciplinas";
            dgvDisciplinas.Size = new Size(277, 203);
            dgvDisciplinas.TabIndex = 5;
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = Color.FromArgb(239, 171, 163);
            btnAgregar.FlatAppearance.BorderSize = 0;
            btnAgregar.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnAgregar.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnAgregar.FlatStyle = FlatStyle.Flat;
            btnAgregar.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            btnAgregar.Location = new Point(111, 281);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(88, 28);
            btnAgregar.TabIndex = 6;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.BackColor = Color.FromArgb(239, 171, 163);
            btnEliminar.FlatAppearance.BorderSize = 0;
            btnEliminar.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnEliminar.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnEliminar.FlatStyle = FlatStyle.Flat;
            btnEliminar.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEliminar.Location = new Point(233, 281);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(78, 28);
            btnEliminar.TabIndex = 8;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = false;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btbBuscar
            // 
            btbBuscar.BackColor = Color.FromArgb(239, 171, 163);
            btbBuscar.FlatAppearance.BorderSize = 0;
            btbBuscar.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btbBuscar.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btbBuscar.FlatStyle = FlatStyle.Flat;
            btbBuscar.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btbBuscar.Location = new Point(345, 281);
            btbBuscar.Name = "btbBuscar";
            btbBuscar.Size = new Size(78, 28);
            btbBuscar.TabIndex = 9;
            btbBuscar.Text = "Buscar";
            btbBuscar.UseVisualStyleBackColor = false;
            btbBuscar.Click += btbBuscar_Click;
            // 
            // Disciplinas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(248, 240, 218);
            BackgroundImage = Properties.Resources.fondo;
            ClientSize = new Size(800, 450);
            Controls.Add(btbBuscar);
            Controls.Add(btnEliminar);
            Controls.Add(btnAgregar);
            Controls.Add(dgvDisciplinas);
            Controls.Add(txtBuscar);
            Controls.Add(txtNombre);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Disciplinas";
            Text = "Disciplinas";
            Load += Disciplinas_Load;
            ((System.ComponentModel.ISupportInitialize)dgvDisciplinas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtNombre;
        private TextBox txtBuscar;
        private DataGridView dgvDisciplinas;
        private Button btnAgregar;
        private Button btnEliminar;
        private Button btbBuscar;
    }
}