﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; 

namespace Athléa2._0
{
    public partial class Resultados : Form
    {
        public Resultados()
        {
            InitializeComponent();
        }

        private void Resultados_Load(object sender, EventArgs e)
        {

            string cadenaConexion = "Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True";
            string consulta = "SELECT id, nombre_completo FROM Atleta";

            using (SqlConnection conexion = new SqlConnection(cadenaConexion))
            using (SqlCommand comando = new SqlCommand(consulta, conexion))
            {
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(comando);
                da.Fill(dt);

                cboAtleta.DataSource = dt;
                cboAtleta.DisplayMember = "nombre_completo"; // Lo que el usuario ve
                cboAtleta.ValueMember = "id";                // Lo que se usa internamente 
            }



        }

        // ID del atleta en el ComboBox
        public class ComboboxItem
        {
            public string Text { get; set; }
            public string Value { get; set; }

            public override string ToString()
            {
                return Text;
            }


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True"))
                {
                    conn.Open();

                    string query = "INSERT INTO Resultado (id, atleta_id, fecha, velocidad, resistencia, fuerza, observaciones) " +
                                   "VALUES (@id, @atleta_id, @fecha, @velocidad, @resistencia, @fuerza, @observaciones)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", int.Parse(txtId.Text));
                        cmd.Parameters.AddWithValue("@atleta_id", int.Parse(cboAtleta.SelectedValue.ToString()));
                        cmd.Parameters.AddWithValue("@fecha", dtpFecha.Value);
                        cmd.Parameters.AddWithValue("@velocidad", decimal.Parse(txtVelocidad.Text));
                        cmd.Parameters.AddWithValue("@resistencia", decimal.Parse(txtResistencia.Text));
                        cmd.Parameters.AddWithValue("@fuerza", decimal.Parse(txtFuerza.Text));
                        cmd.Parameters.AddWithValue("@observaciones", txtObservaciones.Text);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Resultado guardado correctamente.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar: " + ex.Message);
            }

        }
    }
}

