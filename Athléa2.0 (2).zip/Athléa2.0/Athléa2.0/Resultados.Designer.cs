﻿namespace Athléa2._0
{
    partial class Resultados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cboAtleta = new ComboBox();
            dtpFecha = new DateTimePicker();
            label1 = new Label();
            label3 = new Label();
            txtVelocidad = new TextBox();
            label4 = new Label();
            label5 = new Label();
            txtResistencia = new TextBox();
            label6 = new Label();
            txtFuerza = new TextBox();
            label7 = new Label();
            txtObservaciones = new TextBox();
            btnGuardar = new Button();
            label8 = new Label();
            label2 = new Label();
            txtId = new TextBox();
            SuspendLayout();
            // 
            // cboAtleta
            // 
            cboAtleta.BackColor = Color.FromArgb(248, 240, 218);
            cboAtleta.FormattingEnabled = true;
            cboAtleta.Location = new Point(206, 83);
            cboAtleta.Name = "cboAtleta";
            cboAtleta.Size = new Size(211, 23);
            cboAtleta.TabIndex = 0;
            // 
            // dtpFecha
            // 
            dtpFecha.Location = new Point(206, 164);
            dtpFecha.Name = "dtpFecha";
            dtpFecha.Size = new Size(213, 23);
            dtpFecha.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label1.Location = new Point(40, 83);
            label1.Name = "label1";
            label1.Size = new Size(150, 19);
            label1.TabIndex = 3;
            label1.Text = "Selecciona el Atleta:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label3.Location = new Point(33, 167);
            label3.Name = "label3";
            label3.Size = new Size(146, 19);
            label3.TabIndex = 5;
            label3.Text = "Selecciona la fecha:";
            // 
            // txtVelocidad
            // 
            txtVelocidad.BackColor = Color.FromArgb(248, 240, 218);
            txtVelocidad.Location = new Point(206, 209);
            txtVelocidad.Name = "txtVelocidad";
            txtVelocidad.Size = new Size(211, 23);
            txtVelocidad.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label4.Location = new Point(27, 209);
            label4.Name = "label4";
            label4.Size = new Size(155, 19);
            label4.TabIndex = 7;
            label4.Text = "Ingresa la velocidad:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label5.Location = new Point(14, 251);
            label5.Name = "label5";
            label5.Size = new Size(165, 19);
            label5.TabIndex = 9;
            label5.Text = "Ingresa la resistencia:";
            // 
            // txtResistencia
            // 
            txtResistencia.BackColor = Color.FromArgb(248, 240, 218);
            txtResistencia.Location = new Point(206, 251);
            txtResistencia.Name = "txtResistencia";
            txtResistencia.Size = new Size(211, 23);
            txtResistencia.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label6.Location = new Point(46, 294);
            label6.Name = "label6";
            label6.Size = new Size(133, 19);
            label6.TabIndex = 11;
            label6.Text = "Ingresa la fuerza:";
            // 
            // txtFuerza
            // 
            txtFuerza.BackColor = Color.FromArgb(248, 240, 218);
            txtFuerza.Location = new Point(206, 294);
            txtFuerza.Name = "txtFuerza";
            txtFuerza.Size = new Size(211, 23);
            txtFuerza.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label7.Location = new Point(65, 343);
            label7.Name = "label7";
            label7.Size = new Size(114, 19);
            label7.TabIndex = 13;
            label7.Text = "Observaciones:";
            // 
            // txtObservaciones
            // 
            txtObservaciones.BackColor = Color.FromArgb(248, 240, 218);
            txtObservaciones.Location = new Point(206, 343);
            txtObservaciones.Multiline = true;
            txtObservaciones.Name = "txtObservaciones";
            txtObservaciones.Size = new Size(211, 23);
            txtObservaciones.TabIndex = 12;
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.FromArgb(239, 171, 163);
            btnGuardar.Cursor = Cursors.Hand;
            btnGuardar.FlatAppearance.BorderColor = Color.FromArgb(186, 221, 127);
            btnGuardar.FlatAppearance.MouseDownBackColor = Color.FromArgb(239, 171, 163);
            btnGuardar.FlatAppearance.MouseOverBackColor = Color.FromArgb(239, 171, 163);
            btnGuardar.FlatStyle = FlatStyle.Flat;
            btnGuardar.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            btnGuardar.Location = new Point(538, 301);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(115, 32);
            btnGuardar.TabIndex = 14;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = false;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(312, 19);
            label8.Name = "label8";
            label8.Size = new Size(137, 31);
            label8.TabIndex = 15;
            label8.Text = "Resultados";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label2.Location = new Point(149, 128);
            label2.Name = "label2";
            label2.Size = new Size(30, 19);
            label2.TabIndex = 17;
            label2.Text = "ID:";
            // 
            // txtId
            // 
            txtId.BackColor = Color.FromArgb(248, 240, 218);
            txtId.Location = new Point(206, 128);
            txtId.Multiline = true;
            txtId.Name = "txtId";
            txtId.Size = new Size(211, 23);
            txtId.TabIndex = 16;
            // 
            // Resultados
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(248, 240, 218);
            BackgroundImage = Properties.Resources.fondo;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(txtId);
            Controls.Add(label8);
            Controls.Add(btnGuardar);
            Controls.Add(label7);
            Controls.Add(txtObservaciones);
            Controls.Add(label6);
            Controls.Add(txtFuerza);
            Controls.Add(label5);
            Controls.Add(txtResistencia);
            Controls.Add(label4);
            Controls.Add(txtVelocidad);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(dtpFecha);
            Controls.Add(cboAtleta);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Resultados";
            Text = "Resultados";
            Load += Resultados_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cboAtleta;
        private DateTimePicker dtpFecha;
        private Label label1;
        private Label label3;
        private TextBox txtVelocidad;
        private Label label4;
        private Label label5;
        private TextBox txtResistencia;
        private Label label6;
        private TextBox txtFuerza;
        private Label label7;
        private TextBox txtObservaciones;
        private Button btnGuardar;
        private Label label8;
        private Label label2;
        private TextBox txtId;
    }
}