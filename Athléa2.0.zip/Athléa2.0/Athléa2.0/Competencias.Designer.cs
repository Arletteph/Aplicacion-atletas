﻿namespace Athléa2._0
{
    partial class Competencias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtCompetencia = new TextBox();
            txtLugar = new TextBox();
            label2 = new Label();
            txtObservaciones = new TextBox();
            label3 = new Label();
            label4 = new Label();
            dtpFecha = new DateTimePicker();
            btnEliminar = new Button();
            btnAgregar = new Button();
            dgvCompetencias = new DataGridView();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvCompetencias).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label1.Location = new Point(89, 108);
            label1.Name = "label1";
            label1.Size = new Size(104, 19);
            label1.TabIndex = 0;
            label1.Text = "Competencia:";
            // 
            // txtCompetencia
            // 
            txtCompetencia.BackColor = Color.FromArgb(248, 240, 218);
            txtCompetencia.Location = new Point(199, 108);
            txtCompetencia.Name = "txtCompetencia";
            txtCompetencia.Size = new Size(214, 23);
            txtCompetencia.TabIndex = 1;
            // 
            // txtLugar
            // 
            txtLugar.BackColor = Color.FromArgb(248, 240, 218);
            txtLugar.Location = new Point(199, 164);
            txtLugar.Name = "txtLugar";
            txtLugar.Size = new Size(214, 23);
            txtLugar.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label2.Location = new Point(138, 164);
            label2.Name = "label2";
            label2.Size = new Size(55, 19);
            label2.TabIndex = 2;
            label2.Text = "Lugar:";
            // 
            // txtObservaciones
            // 
            txtObservaciones.BackColor = Color.FromArgb(248, 240, 218);
            txtObservaciones.Location = new Point(199, 265);
            txtObservaciones.Multiline = true;
            txtObservaciones.Name = "txtObservaciones";
            txtObservaciones.Size = new Size(214, 23);
            txtObservaciones.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label3.Location = new Point(79, 269);
            label3.Name = "label3";
            label3.Size = new Size(114, 19);
            label3.TabIndex = 4;
            label3.Text = "Observaciones:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label4.Location = new Point(138, 217);
            label4.Name = "label4";
            label4.Size = new Size(55, 19);
            label4.TabIndex = 6;
            label4.Text = "Fecha:";
            // 
            // dtpFecha
            // 
            dtpFecha.Location = new Point(199, 214);
            dtpFecha.Name = "dtpFecha";
            dtpFecha.Size = new Size(214, 23);
            dtpFecha.TabIndex = 7;
            // 
            // btnEliminar
            // 
            btnEliminar.BackColor = Color.FromArgb(239, 171, 163);
            btnEliminar.Cursor = Cursors.Hand;
            btnEliminar.FlatAppearance.BorderColor = Color.FromArgb(186, 221, 127);
            btnEliminar.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnEliminar.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnEliminar.FlatStyle = FlatStyle.Flat;
            btnEliminar.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            btnEliminar.Location = new Point(188, 384);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(83, 30);
            btnEliminar.TabIndex = 9;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = false;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = Color.FromArgb(239, 171, 163);
            btnAgregar.Cursor = Cursors.Hand;
            btnAgregar.FlatAppearance.BorderColor = Color.FromArgb(186, 221, 127);
            btnAgregar.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnAgregar.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnAgregar.FlatStyle = FlatStyle.Flat;
            btnAgregar.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            btnAgregar.Location = new Point(327, 384);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(86, 30);
            btnAgregar.TabIndex = 10;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // dgvCompetencias
            // 
            dgvCompetencias.AllowUserToAddRows = false;
            dgvCompetencias.BackgroundColor = Color.FromArgb(186, 221, 127);
            dgvCompetencias.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCompetencias.Location = new Point(457, 108);
            dgvCompetencias.MultiSelect = false;
            dgvCompetencias.Name = "dgvCompetencias";
            dgvCompetencias.ReadOnly = true;
            dgvCompetencias.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCompetencias.Size = new Size(299, 271);
            dgvCompetencias.TabIndex = 11;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(338, 30);
            label5.Name = "label5";
            label5.Size = new Size(177, 31);
            label5.TabIndex = 12;
            label5.Text = "Competencias:";
            // 
            // Competencias
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(248, 240, 218);
            ClientSize = new Size(800, 450);
            Controls.Add(label5);
            Controls.Add(dgvCompetencias);
            Controls.Add(btnAgregar);
            Controls.Add(btnEliminar);
            Controls.Add(dtpFecha);
            Controls.Add(label4);
            Controls.Add(txtObservaciones);
            Controls.Add(label3);
            Controls.Add(txtLugar);
            Controls.Add(label2);
            Controls.Add(txtCompetencia);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Competencias";
            Text = "Competencias";
            ((System.ComponentModel.ISupportInitialize)dgvCompetencias).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtCompetencia;
        private TextBox txtLugar;
        private Label label2;
        private TextBox txtObservaciones;
        private Label label3;
        private Label label4;
        private DateTimePicker dtpFecha;
        private Button btnEliminar;
        private Button btnAgregar;
        private DataGridView dgvCompetencias;
        private Label label5;
    }
}