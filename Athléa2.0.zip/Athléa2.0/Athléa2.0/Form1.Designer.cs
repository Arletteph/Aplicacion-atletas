﻿namespace Athléa2._0
{
    partial class FormPadre
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPadre));
            panel1 = new Panel();
            btnMaximixar = new PictureBox();
            btnMinimizar = new PictureBox();
            btnRestaurar = new PictureBox();
            btnCerrar = new PictureBox();
            panelMenu = new Panel();
            pictureBox1 = new PictureBox();
            pictureBox5 = new PictureBox();
            panel10 = new Panel();
            btnReportes = new Button();
            panel9 = new Panel();
            btnRendimiento = new Button();
            panel8 = new Panel();
            btnCompetencias = new Button();
            panel7 = new Panel();
            btnEntrenamientos = new Button();
            panel6 = new Panel();
            panel5 = new Panel();
            btnDisciplinas = new Button();
            btnAtletas = new Button();
            panelContenedor = new Panel();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnMaximixar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnMinimizar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnRestaurar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnCerrar).BeginInit();
            panelMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(186, 221, 127);
            panel1.Controls.Add(btnMaximixar);
            panel1.Controls.Add(btnMinimizar);
            panel1.Controls.Add(btnRestaurar);
            panel1.Controls.Add(btnCerrar);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1300, 36);
            panel1.TabIndex = 0;
            panel1.MouseDown += panel1_MouseDown;
            // 
            // btnMaximixar
            // 
            btnMaximixar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMaximixar.Cursor = Cursors.Hand;
            btnMaximixar.Image = (Image)resources.GetObject("btnMaximixar.Image");
            btnMaximixar.Location = new Point(1224, 6);
            btnMaximixar.Name = "btnMaximixar";
            btnMaximixar.Size = new Size(29, 27);
            btnMaximixar.SizeMode = PictureBoxSizeMode.Zoom;
            btnMaximixar.TabIndex = 2;
            btnMaximixar.TabStop = false;
            btnMaximixar.Click += btnMaximixar_Click;
            // 
            // btnMinimizar
            // 
            btnMinimizar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMinimizar.Cursor = Cursors.Hand;
            btnMinimizar.Image = (Image)resources.GetObject("btnMinimizar.Image");
            btnMinimizar.Location = new Point(1189, 6);
            btnMinimizar.Name = "btnMinimizar";
            btnMinimizar.Size = new Size(29, 27);
            btnMinimizar.SizeMode = PictureBoxSizeMode.Zoom;
            btnMinimizar.TabIndex = 3;
            btnMinimizar.TabStop = false;
            btnMinimizar.Click += btnMinimizar_Click;
            // 
            // btnRestaurar
            // 
            btnRestaurar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnRestaurar.Cursor = Cursors.Hand;
            btnRestaurar.Image = (Image)resources.GetObject("btnRestaurar.Image");
            btnRestaurar.Location = new Point(1224, 6);
            btnRestaurar.Name = "btnRestaurar";
            btnRestaurar.Size = new Size(29, 27);
            btnRestaurar.SizeMode = PictureBoxSizeMode.Zoom;
            btnRestaurar.TabIndex = 1;
            btnRestaurar.TabStop = false;
            btnRestaurar.Click += btnRestaurar_Click;
            // 
            // btnCerrar
            // 
            btnCerrar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnCerrar.Cursor = Cursors.Hand;
            btnCerrar.Image = (Image)resources.GetObject("btnCerrar.Image");
            btnCerrar.Location = new Point(1259, 6);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(29, 27);
            btnCerrar.SizeMode = PictureBoxSizeMode.Zoom;
            btnCerrar.TabIndex = 0;
            btnCerrar.TabStop = false;
            btnCerrar.Click += btnCerrar_Click;
            // 
            // panelMenu
            // 
            panelMenu.BackColor = Color.FromArgb(239, 171, 163);
            panelMenu.Controls.Add(pictureBox1);
            panelMenu.Controls.Add(pictureBox5);
            panelMenu.Controls.Add(panel10);
            panelMenu.Controls.Add(btnReportes);
            panelMenu.Controls.Add(panel9);
            panelMenu.Controls.Add(btnRendimiento);
            panelMenu.Controls.Add(panel8);
            panelMenu.Controls.Add(btnCompetencias);
            panelMenu.Controls.Add(panel7);
            panelMenu.Controls.Add(btnEntrenamientos);
            panelMenu.Controls.Add(panel6);
            panelMenu.Controls.Add(panel5);
            panelMenu.Controls.Add(btnDisciplinas);
            panelMenu.Controls.Add(btnAtletas);
            panelMenu.Dock = DockStyle.Left;
            panelMenu.Location = new Point(0, 36);
            panelMenu.Name = "panelMenu";
            panelMenu.Size = new Size(185, 614);
            panelMenu.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = Properties.Resources.salir;
            pictureBox1.Location = new Point(0, 579);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(51, 35);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.Post_de_Instagram_Ubicación_Auzl_Moderno;
            pictureBox5.Location = new Point(0, -10);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(209, 180);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 12;
            pictureBox5.TabStop = false;
            // 
            // panel10
            // 
            panel10.BackColor = Color.FromArgb(186, 221, 127);
            panel10.Location = new Point(3, 428);
            panel10.Name = "panel10";
            panel10.Size = new Size(5, 33);
            panel10.TabIndex = 11;
            // 
            // btnReportes
            // 
            btnReportes.Cursor = Cursors.Hand;
            btnReportes.FlatAppearance.BorderSize = 0;
            btnReportes.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnReportes.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReportes.ForeColor = Color.FromArgb(248, 240, 218);
            btnReportes.Location = new Point(12, 428);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(167, 33);
            btnReportes.TabIndex = 10;
            btnReportes.Text = "Reportes Generales";
            btnReportes.UseVisualStyleBackColor = true;
            btnReportes.Click += btnReportes_Click;
            // 
            // panel9
            // 
            panel9.BackColor = Color.FromArgb(186, 221, 127);
            panel9.Location = new Point(3, 377);
            panel9.Name = "panel9";
            panel9.Size = new Size(5, 33);
            panel9.TabIndex = 9;
            // 
            // btnRendimiento
            // 
            btnRendimiento.Cursor = Cursors.Hand;
            btnRendimiento.FlatAppearance.BorderSize = 0;
            btnRendimiento.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnRendimiento.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnRendimiento.FlatStyle = FlatStyle.Flat;
            btnRendimiento.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRendimiento.ForeColor = Color.FromArgb(248, 240, 218);
            btnRendimiento.Location = new Point(12, 377);
            btnRendimiento.Name = "btnRendimiento";
            btnRendimiento.Size = new Size(167, 33);
            btnRendimiento.TabIndex = 8;
            btnRendimiento.Text = "Resultados";
            btnRendimiento.UseVisualStyleBackColor = true;
            btnRendimiento.Click += btnRendimiento_Click;
            // 
            // panel8
            // 
            panel8.BackColor = Color.FromArgb(186, 221, 127);
            panel8.Location = new Point(3, 329);
            panel8.Name = "panel8";
            panel8.Size = new Size(5, 33);
            panel8.TabIndex = 7;
            // 
            // btnCompetencias
            // 
            btnCompetencias.Cursor = Cursors.Hand;
            btnCompetencias.FlatAppearance.BorderSize = 0;
            btnCompetencias.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnCompetencias.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnCompetencias.FlatStyle = FlatStyle.Flat;
            btnCompetencias.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCompetencias.ForeColor = Color.FromArgb(248, 240, 218);
            btnCompetencias.Location = new Point(12, 329);
            btnCompetencias.Name = "btnCompetencias";
            btnCompetencias.Size = new Size(167, 33);
            btnCompetencias.TabIndex = 6;
            btnCompetencias.Text = "Competencias";
            btnCompetencias.UseVisualStyleBackColor = true;
            btnCompetencias.Click += btnCompetencias_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.FromArgb(186, 221, 127);
            panel7.Location = new Point(4, 279);
            panel7.Name = "panel7";
            panel7.Size = new Size(5, 33);
            panel7.TabIndex = 5;
            // 
            // btnEntrenamientos
            // 
            btnEntrenamientos.Cursor = Cursors.Hand;
            btnEntrenamientos.FlatAppearance.BorderSize = 0;
            btnEntrenamientos.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnEntrenamientos.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnEntrenamientos.FlatStyle = FlatStyle.Flat;
            btnEntrenamientos.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEntrenamientos.ForeColor = Color.FromArgb(248, 240, 218);
            btnEntrenamientos.Location = new Point(13, 279);
            btnEntrenamientos.Name = "btnEntrenamientos";
            btnEntrenamientos.Size = new Size(167, 33);
            btnEntrenamientos.TabIndex = 4;
            btnEntrenamientos.Text = "Entrenamientos";
            btnEntrenamientos.UseVisualStyleBackColor = true;
            btnEntrenamientos.Click += btnEntrenamientos_Click;
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(186, 221, 127);
            panel6.Location = new Point(3, 230);
            panel6.Name = "panel6";
            panel6.Size = new Size(5, 33);
            panel6.TabIndex = 3;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(186, 221, 127);
            panel5.Location = new Point(3, 176);
            panel5.Name = "panel5";
            panel5.Size = new Size(5, 33);
            panel5.TabIndex = 3;
            // 
            // btnDisciplinas
            // 
            btnDisciplinas.Cursor = Cursors.Hand;
            btnDisciplinas.FlatAppearance.BorderSize = 0;
            btnDisciplinas.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnDisciplinas.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnDisciplinas.FlatStyle = FlatStyle.Flat;
            btnDisciplinas.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDisciplinas.ForeColor = Color.FromArgb(248, 240, 218);
            btnDisciplinas.Location = new Point(12, 230);
            btnDisciplinas.Name = "btnDisciplinas";
            btnDisciplinas.Size = new Size(167, 33);
            btnDisciplinas.TabIndex = 2;
            btnDisciplinas.Text = "Disciplinas";
            btnDisciplinas.UseVisualStyleBackColor = true;
            btnDisciplinas.Click += btnDisciplinas_Click;
            // 
            // btnAtletas
            // 
            btnAtletas.Cursor = Cursors.Hand;
            btnAtletas.FlatAppearance.BorderSize = 0;
            btnAtletas.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnAtletas.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnAtletas.FlatStyle = FlatStyle.Flat;
            btnAtletas.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAtletas.ForeColor = Color.FromArgb(248, 240, 218);
            btnAtletas.Location = new Point(12, 176);
            btnAtletas.Name = "btnAtletas";
            btnAtletas.Size = new Size(167, 33);
            btnAtletas.TabIndex = 2;
            btnAtletas.Text = "Atletas";
            btnAtletas.UseVisualStyleBackColor = true;
            btnAtletas.Click += btnAtletas_Click;
            // 
            // panelContenedor
            // 
            panelContenedor.BackColor = Color.FromArgb(248, 240, 218);
            panelContenedor.Dock = DockStyle.Fill;
            panelContenedor.Location = new Point(185, 36);
            panelContenedor.Name = "panelContenedor";
            panelContenedor.Size = new Size(1115, 614);
            panelContenedor.TabIndex = 2;
            panelContenedor.Paint += panelContenedor_Paint;
            // 
            // FormPadre
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1300, 650);
            Controls.Add(panelContenedor);
            Controls.Add(panelMenu);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FormPadre";
            Text = "FormPadre";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)btnMaximixar).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnMinimizar).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnRestaurar).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnCerrar).EndInit();
            panelMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panelMenu;
        private Panel panelContenedor;
        private PictureBox btnCerrar;
        private PictureBox btnMinimizar;
        private PictureBox btnMaximixar;
        private PictureBox btnRestaurar;
        private PictureBox pictureBox5;
        private Panel panel10;
        private Button btnReportes;
        private Panel panel9;
        private Button btnRendimiento;
        private Panel panel8;
        private Button btnCompetencias;
        private Panel panel7;
        private Button btnEntrenamientos;
        private Panel panel6;
        private Panel panel5;
        private Button btnDisciplinas;
        private Button btnAtletas;
        private PictureBox pictureBox1;
    }
}
