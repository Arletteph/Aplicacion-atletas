﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Athléa2._0
{
    public partial class Competencias : Form
    {
        public Competencias()
        {
            InitializeComponent();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvCompetencias.SelectedRows.Count > 0)
            {
                // Obtener el ID de la competencia desde la fila seleccionada
                int idCompetencia = Convert.ToInt32(dgvCompetencias.SelectedRows[0].Cells["id_competencias"].Value);

                // Confirmar si de verdad desea eliminar
                DialogResult confirmacion = MessageBox.Show("¿Seguro que deseas eliminar esta competencia?", "Confirmar eliminación", MessageBoxButtons.YesNo);
                if (confirmacion == DialogResult.Yes)
                {
                    string cadena = "Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True"; // usa tu cadena real
                    using (SqlConnection conexion = new SqlConnection(cadena))
                    {
                        conexion.Open();
                        string consulta = "DELETE FROM Competencia WHERE id_competencias = @id";
                        SqlCommand comando = new SqlCommand(consulta, conexion);
                        comando.Parameters.AddWithValue("@id", idCompetencia);
                        comando.ExecuteNonQuery();
                    }

                    MessageBox.Show("Competencia eliminada correctamente.");
                    // Actualizar el DataGridView
                    CargarDatosCompetencias(); 
                }
            }
            else
            {
                MessageBox.Show("Por favor selecciona una competencia para eliminar.");
            }

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True"))
            {
                conexion.Open();

                string query = "INSERT INTO Competencia (Nombre, Lugar, Fecha, Observaciones) VALUES (@Nombre, @Lugar, @Fecha, @Observaciones)";
                SqlCommand comando = new SqlCommand(query, conexion);

                comando.Parameters.AddWithValue("@Nombre", txtCompetencia.Text);
                comando.Parameters.AddWithValue("@Lugar", txtLugar.Text);
                comando.Parameters.AddWithValue("@Fecha", dtpFecha.Value);
                comando.Parameters.AddWithValue("@Observaciones", txtObservaciones.Text);

                comando.ExecuteNonQuery();
                MessageBox.Show("Competencia agregada correctamente.");

                CargarCompetencias();
               
            }
        }


        private void CargarCompetencias()
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True"))
            {
                conexion.Open();

                string query = "SELECT * FROM Competencia";
                SqlDataAdapter adaptador = new SqlDataAdapter(query, conexion);
                DataTable tabla = new DataTable();
                adaptador.Fill(tabla);

                dgvCompetencias.DataSource = tabla;
            }
        }

        private void CargarDatosCompetencias()
        {
            string cadena = "Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True";
            using (SqlConnection conexion = new SqlConnection(cadena))
            {
                conexion.Open();
                SqlDataAdapter adaptador = new SqlDataAdapter("SELECT * FROM Competencia", conexion);
                DataTable tabla = new DataTable();
                adaptador.Fill(tabla);
                dgvCompetencias.DataSource = tabla;
            }
        }
    }
}
