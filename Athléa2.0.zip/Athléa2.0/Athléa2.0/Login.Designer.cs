﻿namespace Athléa2._0
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            panel2 = new Panel();
            btnMaximixar = new PictureBox();
            btnMinimizar = new PictureBox();
            btnRestaurar = new PictureBox();
            btnCerrar = new PictureBox();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            panellogin = new Panel();
            button1 = new Button();
            panel4 = new Panel();
            panel3 = new Panel();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label2 = new Label();
            label1 = new Label();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnMaximixar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnMinimizar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnRestaurar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnCerrar).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panellogin.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(186, 221, 127);
            panel2.Controls.Add(btnMaximixar);
            panel2.Controls.Add(btnMinimizar);
            panel2.Controls.Add(btnRestaurar);
            panel2.Controls.Add(btnCerrar);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(900, 45);
            panel2.TabIndex = 1;
            // 
            // btnMaximixar
            // 
            btnMaximixar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMaximixar.Cursor = Cursors.Hand;
            btnMaximixar.Image = (Image)resources.GetObject("btnMaximixar.Image");
            btnMaximixar.Location = new Point(824, 12);
            btnMaximixar.Name = "btnMaximixar";
            btnMaximixar.Size = new Size(29, 27);
            btnMaximixar.SizeMode = PictureBoxSizeMode.Zoom;
            btnMaximixar.TabIndex = 6;
            btnMaximixar.TabStop = false;
            btnMaximixar.Click += btnMaximixar_Click;
            // 
            // btnMinimizar
            // 
            btnMinimizar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMinimizar.Cursor = Cursors.Hand;
            btnMinimizar.Image = (Image)resources.GetObject("btnMinimizar.Image");
            btnMinimizar.Location = new Point(789, 12);
            btnMinimizar.Name = "btnMinimizar";
            btnMinimizar.Size = new Size(29, 27);
            btnMinimizar.SizeMode = PictureBoxSizeMode.Zoom;
            btnMinimizar.TabIndex = 7;
            btnMinimizar.TabStop = false;
            btnMinimizar.Click += btnMinimizar_Click;
            // 
            // btnRestaurar
            // 
            btnRestaurar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnRestaurar.Cursor = Cursors.Hand;
            btnRestaurar.Image = (Image)resources.GetObject("btnRestaurar.Image");
            btnRestaurar.Location = new Point(824, 12);
            btnRestaurar.Name = "btnRestaurar";
            btnRestaurar.Size = new Size(29, 27);
            btnRestaurar.SizeMode = PictureBoxSizeMode.Zoom;
            btnRestaurar.TabIndex = 5;
            btnRestaurar.TabStop = false;
            btnRestaurar.Click += btnRestaurar_Click;
            // 
            // btnCerrar
            // 
            btnCerrar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnCerrar.Cursor = Cursors.Hand;
            btnCerrar.Image = (Image)resources.GetObject("btnCerrar.Image");
            btnCerrar.Location = new Point(859, 12);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(29, 27);
            btnCerrar.SizeMode = PictureBoxSizeMode.Zoom;
            btnCerrar.TabIndex = 4;
            btnCerrar.TabStop = false;
            btnCerrar.Click += btnCerrar_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(239, 171, 163);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 45);
            panel1.Name = "panel1";
            panel1.Size = new Size(200, 258);
            panel1.TabIndex = 2;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-25, -33);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(266, 303);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panellogin
            // 
            panellogin.BackColor = Color.FromArgb(248, 240, 218);
            panellogin.Controls.Add(button1);
            panellogin.Controls.Add(panel4);
            panellogin.Controls.Add(panel3);
            panellogin.Controls.Add(textBox2);
            panellogin.Controls.Add(textBox1);
            panellogin.Controls.Add(label2);
            panellogin.Controls.Add(label1);
            panellogin.Dock = DockStyle.Fill;
            panellogin.Location = new Point(200, 45);
            panellogin.Name = "panellogin";
            panellogin.Size = new Size(700, 258);
            panellogin.TabIndex = 3;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(239, 171, 163);
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(555, 176);
            button1.Name = "button1";
            button1.Size = new Size(83, 32);
            button1.TabIndex = 6;
            button1.Text = "Ingresar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(186, 221, 127);
            panel4.Location = new Point(215, 166);
            panel4.Name = "panel4";
            panel4.Size = new Size(300, 1);
            panel4.TabIndex = 5;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(186, 221, 127);
            panel3.Location = new Point(215, 113);
            panel3.Name = "panel3";
            panel3.Size = new Size(300, 1);
            panel3.TabIndex = 4;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(248, 240, 218);
            textBox2.BorderStyle = BorderStyle.None;
            textBox2.Location = new Point(215, 144);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(215, 16);
            textBox2.TabIndex = 3;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(248, 240, 218);
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Location = new Point(215, 91);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(215, 16);
            textBox1.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Small", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(84, 144);
            label2.Name = "label2";
            label2.Size = new Size(113, 24);
            label2.TabIndex = 1;
            label2.Text = "Contraseña:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Small", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(113, 84);
            label1.Name = "label1";
            label1.Size = new Size(84, 24);
            label1.TabIndex = 0;
            label1.Text = "Usuario:";
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(900, 303);
            Controls.Add(panellogin);
            Controls.Add(panel1);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Login";
            Text = "Login";
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)btnMaximixar).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnMinimizar).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnRestaurar).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnCerrar).EndInit();
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panellogin.ResumeLayout(false);
            panellogin.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private Panel panel1;
        private Panel panellogin;
        private PictureBox btnMaximixar;
        private PictureBox btnMinimizar;
        private PictureBox btnRestaurar;
        private PictureBox btnCerrar;
        private PictureBox pictureBox1;
        private Label label2;
        private Label label1;
        private Button button1;
        private Panel panel4;
        private Panel panel3;
        private TextBox textBox2;
        private TextBox textBox1;
    }
}