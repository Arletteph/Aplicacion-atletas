﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Athléa2._0
{
    public partial class Disciplinas : Form
    {
        public Disciplinas()
        {
            InitializeComponent();
        }



        private void Disciplinas_Load(object sender, EventArgs e)
        {
            MostrarDisciplinas();
        }

        private void MostrarDisciplinas()
        {
            string conexion = "Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True";
            string query = "SELECT * FROM Disciplinas";

            using (SqlConnection conn = new SqlConnection(conexion))
            using (SqlDataAdapter adaptador = new SqlDataAdapter(query, conn))
            {
                DataTable tabla = new DataTable();
                adaptador.Fill(tabla);
                dgvDisciplinas.DataSource = tabla;
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            AgregarDisciplinas formDisciplinas = new AgregarDisciplinas();
            formDisciplinas.ShowDialog(); 
            CargarDisciplinas();
        }


      

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvDisciplinas.CurrentRow == null)
            {
                MessageBox.Show("Seleccione una disciplina para eliminar.");
                return;
            }

            int id = Convert.ToInt32(dgvDisciplinas.CurrentRow.Cells["id"].Value);

            string conexion = "Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True";
            string query = "DELETE FROM Disciplinas WHERE id = @id";

            using (SqlConnection conn = new SqlConnection(conexion))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Disciplina eliminada.");
            MostrarDisciplinas();
        }

        private void btbBuscar_Click(object sender, EventArgs e)
        {
            string textoBusqueda = txtBuscar.Text.Trim(); 

            if (textoBusqueda != "")
            {
                SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True");
                conexion.Open();

                string consulta = "SELECT * FROM Disciplinas WHERE nombre LIKE @nombre";
                SqlCommand comando = new SqlCommand(consulta, conexion);
                comando.Parameters.AddWithValue("@nombre", "%" + textoBusqueda + "%");

                SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                DataTable tabla = new DataTable();
                adaptador.Fill(tabla);
                dgvDisciplinas.DataSource = tabla;

                conexion.Close();
            }
            else
            {
                MessageBox.Show("Por favor escribe el nombre de la disciplina que deseas buscar.");
            }
        }


        private void CargarDisciplinas()
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True"))
            {
                conexion.Open();

                string query = "SELECT * FROM Disciplinas";
                SqlDataAdapter adaptador = new SqlDataAdapter(query, conexion);
                DataTable tabla = new DataTable();
                adaptador.Fill(tabla);

                dgvDisciplinas.DataSource = tabla;
            }
        }
    }
} 
