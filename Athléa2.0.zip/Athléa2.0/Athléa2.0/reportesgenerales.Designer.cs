﻿namespace Athléa2._0
{
    partial class reportesgenerales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtTitulo = new TextBox();
            rtbContenido = new RichTextBox();
            label3 = new Label();
            dgvReportes = new DataGridView();
            label4 = new Label();
            dtpFecha = new DateTimePicker();
            btnGuardar = new Button();
            btnConsultar = new Button();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvReportes).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(298, 20);
            label1.Name = "label1";
            label1.Size = new Size(230, 31);
            label1.TabIndex = 0;
            label1.Text = "Reportes Generales";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Small", 9F, FontStyle.Bold);
            label2.Location = new Point(1, 101);
            label2.Name = "label2";
            label2.Size = new Size(127, 18);
            label2.TabIndex = 1;
            label2.Text = "Titulo del reporte:";
            // 
            // txtTitulo
            // 
            txtTitulo.BackColor = Color.FromArgb(248, 240, 218);
            txtTitulo.Location = new Point(133, 102);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(230, 23);
            txtTitulo.TabIndex = 2;
            // 
            // rtbContenido
            // 
            rtbContenido.BackColor = Color.WhiteSmoke;
            rtbContenido.Location = new Point(119, 214);
            rtbContenido.Name = "rtbContenido";
            rtbContenido.Size = new Size(244, 186);
            rtbContenido.TabIndex = 3;
            rtbContenido.Text = "";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Small", 9F, FontStyle.Bold);
            label3.Location = new Point(21, 215);
            label3.Name = "label3";
            label3.Size = new Size(78, 18);
            label3.TabIndex = 4;
            label3.Text = "Contenido:";
            // 
            // dgvReportes
            // 
            dgvReportes.BackgroundColor = Color.FromArgb(186, 221, 127);
            dgvReportes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvReportes.Location = new Point(474, 162);
            dgvReportes.Name = "dgvReportes";
            dgvReportes.Size = new Size(240, 183);
            dgvReportes.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Small", 9F, FontStyle.Bold);
            label4.Location = new Point(79, 144);
            label4.Name = "label4";
            label4.Size = new Size(49, 18);
            label4.TabIndex = 6;
            label4.Text = "Fecha:";
            // 
            // dtpFecha
            // 
            dtpFecha.Location = new Point(134, 144);
            dtpFecha.Name = "dtpFecha";
            dtpFecha.Size = new Size(229, 23);
            dtpFecha.TabIndex = 7;
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.FromArgb(239, 171, 163);
            btnGuardar.Cursor = Cursors.Hand;
            btnGuardar.FlatAppearance.BorderColor = Color.FromArgb(186, 221, 127);
            btnGuardar.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnGuardar.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnGuardar.FlatStyle = FlatStyle.Flat;
            btnGuardar.Location = new Point(483, 387);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 8;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = false;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnConsultar
            // 
            btnConsultar.BackColor = Color.FromArgb(239, 171, 163);
            btnConsultar.Cursor = Cursors.Hand;
            btnConsultar.FlatAppearance.BorderColor = Color.FromArgb(186, 221, 127);
            btnConsultar.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnConsultar.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnConsultar.FlatStyle = FlatStyle.Flat;
            btnConsultar.Location = new Point(614, 387);
            btnConsultar.Name = "btnConsultar";
            btnConsultar.Size = new Size(75, 23);
            btnConsultar.TabIndex = 9;
            btnConsultar.Text = "Consultar";
            btnConsultar.UseVisualStyleBackColor = false;
            btnConsultar.Click += btnConsultar_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Small", 9F, FontStyle.Bold);
            label5.Location = new Point(474, 117);
            label5.Name = "label5";
            label5.Size = new Size(141, 18);
            label5.TabIndex = 10;
            label5.Text = "Reportes guardados:";
            // 
            // reportesgenerales
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(248, 240, 218);
            ClientSize = new Size(800, 450);
            Controls.Add(label5);
            Controls.Add(btnConsultar);
            Controls.Add(btnGuardar);
            Controls.Add(dtpFecha);
            Controls.Add(label4);
            Controls.Add(dgvReportes);
            Controls.Add(label3);
            Controls.Add(rtbContenido);
            Controls.Add(txtTitulo);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "reportesgenerales";
            Text = "reportesgenerales";
            ((System.ComponentModel.ISupportInitialize)dgvReportes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtTitulo;
        private RichTextBox rtbContenido;
        private Label label3;
        private DataGridView dgvReportes;
        private Label label4;
        private DateTimePicker dtpFecha;
        private Button btnGuardar;
        private Button btnConsultar;
        private Label label5;
    }
}