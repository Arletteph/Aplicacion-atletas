﻿namespace Athléa2._0
{
    partial class Entrenamientos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dtpFecha = new DateTimePicker();
            label1 = new Label();
            txtDuracion = new TextBox();
            txtObservaciones = new TextBox();
            label2 = new Label();
            label3 = new Label();
            button1 = new Button();
            dataGridView1 = new DataGridView();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtTipo = new TextBox();
            cbDisciplina = new ComboBox();
            label7 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dtpFecha
            // 
            dtpFecha.CalendarMonthBackground = Color.FromArgb(248, 240, 218);
            dtpFecha.CalendarTitleBackColor = Color.FromArgb(186, 221, 127);
            dtpFecha.Location = new Point(166, 112);
            dtpFecha.Name = "dtpFecha";
            dtpFecha.Size = new Size(222, 23);
            dtpFecha.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Small", 11.25F, FontStyle.Bold);
            label1.Location = new Point(93, 112);
            label1.Name = "label1";
            label1.Size = new Size(62, 23);
            label1.TabIndex = 1;
            label1.Text = "Fecha:";
            // 
            // txtDuracion
            // 
            txtDuracion.BackColor = Color.FromArgb(248, 240, 218);
            txtDuracion.Location = new Point(241, 162);
            txtDuracion.Name = "txtDuracion";
            txtDuracion.Size = new Size(147, 23);
            txtDuracion.TabIndex = 2;
            // 
            // txtObservaciones
            // 
            txtObservaciones.BackColor = Color.FromArgb(248, 240, 218);
            txtObservaciones.Location = new Point(241, 258);
            txtObservaciones.Name = "txtObservaciones";
            txtObservaciones.Size = new Size(147, 23);
            txtObservaciones.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Small", 11.25F, FontStyle.Bold);
            label2.Location = new Point(93, 255);
            label2.Name = "label2";
            label2.Size = new Size(132, 23);
            label2.TabIndex = 4;
            label2.Text = "Observaciones:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Small", 11.25F, FontStyle.Bold);
            label3.Location = new Point(35, 159);
            label3.Name = "label3";
            label3.Size = new Size(200, 23);
            label3.TabIndex = 5;
            label3.Text = "Duración (en minutos):";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(239, 171, 163);
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Sitka Small", 11.25F, FontStyle.Bold);
            button1.Location = new Point(593, 385);
            button1.Name = "button1";
            button1.Size = new Size(98, 30);
            button1.TabIndex = 6;
            button1.Text = "Guardar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(186, 221, 127);
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.GridColor = Color.FromArgb(186, 221, 127);
            dataGridView1.Location = new Point(420, 99);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(341, 252);
            dataGridView1.TabIndex = 7;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Small", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(278, 18);
            label4.Name = "label4";
            label4.Size = new Size(222, 35);
            label4.TabIndex = 8;
            label4.Text = "Entrenamientos";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Small", 11.25F, FontStyle.Bold);
            label5.Location = new Point(166, 70);
            label5.Name = "label5";
            label5.Size = new Size(163, 23);
            label5.TabIndex = 9;
            label5.Text = "Selecciona la fecha";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Small", 11.25F, FontStyle.Bold);
            label6.Location = new Point(35, 215);
            label6.Name = "label6";
            label6.Size = new Size(200, 23);
            label6.TabIndex = 11;
            label6.Text = "Tipo de entrenamiento:";
            // 
            // txtTipo
            // 
            txtTipo.BackColor = Color.FromArgb(248, 240, 218);
            txtTipo.Location = new Point(241, 215);
            txtTipo.Name = "txtTipo";
            txtTipo.Size = new Size(147, 23);
            txtTipo.TabIndex = 10;
            // 
            // cbDisciplina
            // 
            cbDisciplina.BackColor = Color.FromArgb(248, 240, 218);
            cbDisciplina.FormattingEnabled = true;
            cbDisciplina.Items.AddRange(new object[] { "Atletismo", "Voleibol", "Baloncesto", "Futbol" });
            cbDisciplina.Location = new Point(241, 311);
            cbDisciplina.Name = "cbDisciplina";
            cbDisciplina.Size = new Size(147, 23);
            cbDisciplina.TabIndex = 12;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Small", 11.25F, FontStyle.Bold);
            label7.Location = new Point(128, 311);
            label7.Name = "label7";
            label7.Size = new Size(97, 23);
            label7.TabIndex = 13;
            label7.Text = "Disciplina:";
            // 
            // Entrenamientos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(248, 240, 218);
            ClientSize = new Size(800, 450);
            Controls.Add(label7);
            Controls.Add(cbDisciplina);
            Controls.Add(label6);
            Controls.Add(txtTipo);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(dataGridView1);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtObservaciones);
            Controls.Add(txtDuracion);
            Controls.Add(label1);
            Controls.Add(dtpFecha);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Entrenamientos";
            Text = "Entrenamientos";
            Load += Entrenamientos_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DateTimePicker dtpFecha;
        private Label label1;
        private TextBox txtDuracion;
        private TextBox txtObservaciones;
        private Label label2;
        private Label label3;
        private Button button1;
        private DataGridView dataGridView1;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtTipo;
        private ComboBox cbDisciplina;
        private Label label7;
    }
}