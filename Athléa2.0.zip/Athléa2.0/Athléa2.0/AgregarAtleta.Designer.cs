﻿namespace Athléa2._0
{
    partial class AgregarAtleta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNombre = new TextBox();
            label1 = new Label();
            label2 = new Label();
            txtEdad = new TextBox();
            label3 = new Label();
            txtNacionalidad = new TextBox();
            label4 = new Label();
            txtProvincia = new TextBox();
            label5 = new Label();
            txtTelefono = new TextBox();
            btnGuardar = new Button();
            btncancelar = new Button();
            rbtnFemenino = new RadioButton();
            rbtnMasculino = new RadioButton();
            label6 = new Label();
            dtpFecha = new DateTimePicker();
            label7 = new Label();
            label8 = new Label();
            txtDisciplina = new TextBox();
            SuspendLayout();
            // 
            // txtNombre
            // 
            txtNombre.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            txtNombre.Location = new Point(197, 88);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(265, 24);
            txtNombre.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label1.Location = new Point(49, 93);
            label1.Name = "label1";
            label1.Size = new Size(137, 19);
            label1.TabIndex = 1;
            label1.Text = "Nombre completo:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label2.Location = new Point(136, 137);
            label2.Name = "label2";
            label2.Size = new Size(49, 19);
            label2.TabIndex = 3;
            label2.Text = "Edad:";
            // 
            // txtEdad
            // 
            txtEdad.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            txtEdad.Location = new Point(197, 134);
            txtEdad.Name = "txtEdad";
            txtEdad.Size = new Size(265, 24);
            txtEdad.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label3.Location = new Point(89, 189);
            label3.Name = "label3";
            label3.Size = new Size(106, 19);
            label3.TabIndex = 5;
            label3.Text = "Nacionalidad:";
            // 
            // txtNacionalidad
            // 
            txtNacionalidad.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            txtNacionalidad.Location = new Point(197, 180);
            txtNacionalidad.Name = "txtNacionalidad";
            txtNacionalidad.Size = new Size(265, 24);
            txtNacionalidad.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label4.Location = new Point(106, 237);
            label4.Name = "label4";
            label4.Size = new Size(80, 19);
            label4.TabIndex = 7;
            label4.Text = "Provincia:";
            // 
            // txtProvincia
            // 
            txtProvincia.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            txtProvincia.Location = new Point(197, 234);
            txtProvincia.Name = "txtProvincia";
            txtProvincia.Size = new Size(265, 24);
            txtProvincia.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label5.Location = new Point(106, 293);
            label5.Name = "label5";
            label5.Size = new Size(74, 19);
            label5.TabIndex = 9;
            label5.Text = "Teléfono:";
            // 
            // txtTelefono
            // 
            txtTelefono.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            txtTelefono.Location = new Point(197, 288);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(265, 24);
            txtTelefono.TabIndex = 8;
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.FromArgb(239, 171, 163);
            btnGuardar.FlatAppearance.BorderColor = Color.FromArgb(186, 221, 127);
            btnGuardar.FlatAppearance.BorderSize = 0;
            btnGuardar.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btnGuardar.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btnGuardar.FlatStyle = FlatStyle.Flat;
            btnGuardar.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            btnGuardar.Location = new Point(623, 436);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(103, 28);
            btnGuardar.TabIndex = 10;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = false;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btncancelar
            // 
            btncancelar.BackColor = Color.FromArgb(239, 171, 163);
            btncancelar.FlatAppearance.BorderColor = Color.FromArgb(186, 221, 127);
            btncancelar.FlatAppearance.BorderSize = 0;
            btncancelar.FlatAppearance.MouseDownBackColor = Color.FromArgb(186, 221, 127);
            btncancelar.FlatAppearance.MouseOverBackColor = Color.FromArgb(186, 221, 127);
            btncancelar.FlatStyle = FlatStyle.Flat;
            btncancelar.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            btncancelar.Location = new Point(733, 436);
            btncancelar.Name = "btncancelar";
            btncancelar.Size = new Size(103, 28);
            btncancelar.TabIndex = 11;
            btncancelar.Text = "Cancelar";
            btncancelar.UseVisualStyleBackColor = false;
            btncancelar.Click += btncancelar_Click;
            // 
            // rbtnFemenino
            // 
            rbtnFemenino.AutoSize = true;
            rbtnFemenino.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            rbtnFemenino.Location = new Point(211, 436);
            rbtnFemenino.Name = "rbtnFemenino";
            rbtnFemenino.Size = new Size(36, 23);
            rbtnFemenino.TabIndex = 12;
            rbtnFemenino.TabStop = true;
            rbtnFemenino.Text = "F";
            rbtnFemenino.UseVisualStyleBackColor = true;
            // 
            // rbtnMasculino
            // 
            rbtnMasculino.AutoSize = true;
            rbtnMasculino.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            rbtnMasculino.Location = new Point(302, 436);
            rbtnMasculino.Name = "rbtnMasculino";
            rbtnMasculino.Size = new Size(40, 23);
            rbtnMasculino.TabIndex = 13;
            rbtnMasculino.TabStop = true;
            rbtnMasculino.Text = "M";
            rbtnMasculino.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label6.Location = new Point(119, 436);
            label6.Name = "label6";
            label6.Size = new Size(46, 19);
            label6.TabIndex = 14;
            label6.Text = "Sexo:";
            // 
            // dtpFecha
            // 
            dtpFecha.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            dtpFecha.Location = new Point(197, 336);
            dtpFecha.Name = "dtpFecha";
            dtpFecha.Size = new Size(265, 24);
            dtpFecha.TabIndex = 15;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label7.Location = new Point(37, 341);
            label7.Name = "label7";
            label7.Size = new Size(158, 19);
            label7.TabIndex = 16;
            label7.Text = "Fecha de nacimiento:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            label8.Location = new Point(106, 387);
            label8.Name = "label8";
            label8.Size = new Size(84, 19);
            label8.TabIndex = 18;
            label8.Text = "Disciplina:";
            // 
            // txtDisciplina
            // 
            txtDisciplina.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold);
            txtDisciplina.Location = new Point(197, 382);
            txtDisciplina.Name = "txtDisciplina";
            txtDisciplina.Size = new Size(265, 24);
            txtDisciplina.TabIndex = 17;
            // 
            // AgregarAtleta
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(248, 240, 218);
            ClientSize = new Size(914, 510);
            Controls.Add(label8);
            Controls.Add(txtDisciplina);
            Controls.Add(label7);
            Controls.Add(dtpFecha);
            Controls.Add(label6);
            Controls.Add(rbtnMasculino);
            Controls.Add(rbtnFemenino);
            Controls.Add(btncancelar);
            Controls.Add(btnGuardar);
            Controls.Add(label5);
            Controls.Add(txtTelefono);
            Controls.Add(label4);
            Controls.Add(txtProvincia);
            Controls.Add(label3);
            Controls.Add(txtNacionalidad);
            Controls.Add(label2);
            Controls.Add(txtEdad);
            Controls.Add(label1);
            Controls.Add(txtNombre);
            Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AgregarAtleta";
            Text = "AgregarAtleta";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNombre;
        private Label label1;
        private Label label2;
        private TextBox txtEdad;
        private Label label3;
        private TextBox txtNacionalidad;
        private Label label4;
        private TextBox txtProvincia;
        private Label label5;
        private TextBox txtTelefono;
        private Button btnGuardar;
        private Button btncancelar;
        private RadioButton rbtnFemenino;
        private RadioButton rbtnMasculino;
        private Label label6;
        private DateTimePicker dtpFecha;
        private Label label7;
        private Label label8;
        private TextBox txtDisciplina;
    }
}