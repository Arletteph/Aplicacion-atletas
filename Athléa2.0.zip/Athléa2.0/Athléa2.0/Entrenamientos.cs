﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Athléa2._0
{
    public partial class Entrenamientos : Form
    {
        public Entrenamientos()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string cadena = "Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True";
;
            SqlConnection conexion = new SqlConnection(cadena);

            conexion.Open();

            string consulta = "insert into Entrenamientos (fecha, tipo, duracion, observaciones, disciplina) values (@fecha, @tipo, @duracion, @observaciones, @disciplina)";
            SqlCommand comando = new SqlCommand(consulta, conexion);

            
            comando.Parameters.AddWithValue("@fecha", dtpFecha.Value); 
            comando.Parameters.AddWithValue("@tipo", txtTipo.Text); 
            comando.Parameters.AddWithValue("@duracion", txtDuracion.Text); 
            comando.Parameters.AddWithValue("@observaciones", txtObservaciones.Text);
            comando.Parameters.AddWithValue("@disciplina", cbDisciplina.SelectedItem.ToString());

            comando.ExecuteNonQuery();

            conexion.Close();
            MessageBox.Show("Entrenamiento guardado correctamente");

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Entrenamientos_Load(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True");
            conexion.Open();

            SqlDataAdapter adaptador = new SqlDataAdapter("select * from Entrenamientos", conexion);
            DataTable tabla = new DataTable();
            adaptador.Fill(tabla);

            dataGridView1.DataSource = tabla;
            conexion.Close(); 
        }
    }
}
