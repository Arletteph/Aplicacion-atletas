﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Athléa2._0
{
    public partial class AgregarDisciplinas : Form
    {
        public AgregarDisciplinas()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text.Trim();
            string descripcion = txtDescripcion.Text.Trim();

            if (nombre == "" || descripcion == "")
            {
                MessageBox.Show("Por favor completa todos los campos.");
                return;
            }

            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True"))
            {
                conexion.Open();

                string query = "INSERT INTO Disciplinas (nombre, descripcion) VALUES (@nombre, @descripcion)";
                SqlCommand comando = new SqlCommand(query, conexion);

                comando.Parameters.AddWithValue("@nombre", nombre);
                comando.Parameters.AddWithValue("@descripcion", descripcion);

                comando.ExecuteNonQuery();
            }

            MessageBox.Show("Disciplina agregada correctamente.");
            this.Close();
        }

    }

}
