﻿using System.Data;
using System.Data.SqlClient;
using System.Runtime.Intrinsics.Arm;




namespace Athléa2._0
{
    public partial class Login : Form
    {
        string connectionString = "Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True;Trust Server Certificate=True";
        bool nuevo;

        public Login()
        {
            InitializeComponent();
        }

        private void btnMaximixar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            btnMaximixar.Visible = false;
            btnRestaurar.Visible = true;
        }

        private void btnRestaurar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            btnRestaurar.Visible = false;
            btnMaximixar.Visible = true;
        }

        private void btnMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string usuario = textBox1.Text.Trim();  // 
            string contrasena = textBox2.Text.Trim();

            string connectionString = "Data Source=DESKTOP-0AUQ6JE\\SQLEXPRESS;Initial Catalog=athléa2;Integrated Security=True";
            string sql = "SELECT id_usuario FROM usuarios WHERE nombre_usuario = @usuario AND contrasena = @contrasena";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@usuario", usuario);
                cmd.Parameters.AddWithValue("@contrasena", contrasena);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    // Guarda el ID del usuario que inició sesión
                    Sesion.idUsuarioActivo =  Convert.ToInt32(reader["id_usuario"]);

                    MessageBox.Show("Bienvenido, " + usuario);

                    FormPadre formularioPrincipal = new FormPadre();
                    formularioPrincipal.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Usuario o contraseña incorrectos.");
                }

                reader.Close();
            }
        }



        public void CargarDatos()
        {


        }

        public static class Sesion
        {
            public static int idUsuarioActivo;
        }

    }
}


